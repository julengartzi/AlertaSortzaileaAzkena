package alertaSortzailea;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Aplikazioaren hasierako menurako klasea.
 */
public class hasierakoMenua extends JFrame {
    /**
     * Klasearen eraikitzailea
     */
    public hasierakoMenua() {
        setTitle("Aukerak");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 350); 
        setLayout(new BorderLayout()); 

        // Texto del título
        JLabel lbltitulua = new JLabel("Alerta sortzailea", SwingConstants.CENTER);
        lbltitulua.setFont(new Font("Arial", Font.BOLD, 24)); 

        // Cargamos la imagen desde un archivo
        ImageIcon imagen = new ImageIcon("irudiak/email.png");
        JLabel lblIrudia = new JLabel(imagen);
        lblIrudia.setHorizontalAlignment(SwingConstants.CENTER); 

        // Botones para acciones
        JButton botoa1 = new JButton("Erregistro berria sartu");
        botoa1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                formularioBerria();
            }
        });

        JButton botoia2 = new JButton("Alertak gestionatu");
        botoia2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                alertakGestionatu();
            }
        });

        JPanel botoiPanela = new JPanel();
        botoiPanela.setLayout(new GridLayout(2, 1));
        botoiPanela.add(botoa1);
        botoiPanela.add(botoia2);

        JPanel goikoPanela = new JPanel(new BorderLayout());
        goikoPanela.add(lbltitulua, BorderLayout.NORTH);
        goikoPanela.add(lblIrudia, BorderLayout.CENTER);

        add(goikoPanela, BorderLayout.CENTER);
        add(botoiPanela, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
        setVisible(true);

        MezuakProgramatu.main(new String[0]);
    }

    /**
     * Alerta-erregistro berri bat sartzeko formularioa bistaratzeko metodoa.
     */
    private void formularioBerria() {
        new erregistroaSartu();
    }

    /**
     * Alertak kudeatzeko metodoa.
     */
    private void alertakGestionatu() {
        erregistroaGestionatu tabla = new erregistroaGestionatu();

        // Fetch data from the database
        try {
            String query = "SELECT * FROM mezua"; // 
            ResultSet resultSet = DatuBasea.executeQuery(query); 
            tabla.updateTableModel(resultSet); 
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Aplikazioa exekutatzeko metodo nagusia.
     * 
     */
    public static void main(String[] args) {
        new hasierakoMenua();
    }
}


