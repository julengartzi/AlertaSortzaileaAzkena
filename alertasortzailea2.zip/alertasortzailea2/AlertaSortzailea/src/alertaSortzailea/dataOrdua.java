package alertaSortzailea;

/**
 * Gai bat, deskribapena, hartzailea, data eta ordua dituen datu-entitate bat irudikatzeko klasea.
 */
class dataOrdua {
	private int id;
    private String gaia;
    private String deskribapena;
    private String jasotzailea;
    private String data;
    private String ordua;
    private int errepikakorra;
    private String maiztasuna;

    /**
     * Ikasgelako eraikitzailea.
     * 
     * @param gaia          
     * @param deskribapena  
     * @param jasotzailea   
     * @param fecha         
     * @param hora       
     */
    public dataOrdua(int id, String gaia, String deskribapena, String jasotzailea, String fecha, String hora, int errepikakorra, String maiztasuna) {
    	this.id = id;
        this.gaia = gaia;
        this.deskribapena = deskribapena;
        this.jasotzailea = jasotzailea;
        this.data = fecha;
        this.ordua = hora;
        this.errepikakorra = errepikakorra;
        this.maiztasuna = maiztasuna;
    }
    
    /**
     * id lortu
     * 
     * @return id
     */
    public int getID() {
        return id;
    }

    /**
     * Gaia lortu
     * 
     * @return gaia
     */
    public String getGaia() {
        return gaia;
    }

    /**
     * Deskribapena lortu
     * 
     * @return deskribapena
     */
    public String getDeskribapena() {
        return deskribapena;
    }

    /**
     * Jasotzailea lortu
     * 
     * @return jasotzailea
     */
    public String getJasotzailea() {
        return jasotzailea;
    }

    /**
     * Data lortu
     * 
     * @return data
     */
    public String getData() {
        return data;
    }

    /**
     * Ordua lortu
     * 
     * @return ordua
     */
    public String getOrdua() {
        return ordua;
    }
    
    /**
     * errepikakorra lortu
     * 
     * @return errepikakorra
     */
    public int getErrepikakorra() {
        return errepikakorra;
    }
    
    /**
     * maiztasuna lortu
     * 
     * @return maiztasuna
     */
    public String getMaiztasuna() {
        return maiztasuna;
    }
    
    

    /**
     * Kate-irudikapen bat itzultzen du.
     * 
     * @return Katea "Gaia: [gaia], Data: [data], Ordua: [ordua]" formatuan irudikatzen duen katea.
     */
    @Override
    public String toString() {
        return "Gaia: " + gaia + ", Data: " + data + ", Ordua: " + ordua;
    }
}
