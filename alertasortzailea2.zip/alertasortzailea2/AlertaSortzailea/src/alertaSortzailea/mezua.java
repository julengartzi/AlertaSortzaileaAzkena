package alertaSortzailea;

/**
 * "mezua" klasea alerta mezuen informazioa gordetzeko erabiltzen da.
 */
public class mezua {
    String gaia;
    String deskribapena;
    String jasotzailea;
    String data;
    String ordua;

    /**
     * "mezua" klasearen eraikitzailea.
     * 
     * @param gaia           Alertaren gaia.
     * @param deskribapena   Alertaren deskribapena.
     * @param jasotzailea    Alerta jasotzeko helbidea.
     * @param data           Alertaren data.
     * @param ordua          Alertaren ordua.
     */
    public mezua(String gaia, String deskribapena, String jasotzailea, String data, String ordua) {
        this.gaia = gaia;
        this.deskribapena = deskribapena;
        this.jasotzailea = jasotzailea;
        this.data = data;
        this.ordua = ordua;
    }
}
